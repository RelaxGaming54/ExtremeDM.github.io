Tip:Play with mods "Project Brutalty or Brutal Doom" to get best experience :)))
This Mod is ver 0.1 you can run launcher:GZDoom or Prboom